package pack2;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Lab7_2_Lab3_IE_JUnit {

	public static String driverPath = "D:\\Selenium\\M3 Selenium Installations\\Selenium Installations\\";

	public static WebDriver driver;

	@BeforeClass
	public static void beforeClass() {

		System.setProperty("webdriver.ie.driver", driverPath
				+ "IEDriverServer.exe");
		driver = new InternetExplorerDriver();

	}

	@Before
	public void beforeMethod() {

		// open url
		driver.get("http://demo.opencart.com/");
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();

	}

	@Test
	public void test() throws InterruptedException {

		// PART 1 : LAUNCH APPLICATION
		// title check
		Assert.assertEquals(driver.getTitle(), "The OpenCart demo store");
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

		// my account
		driver.findElement(By.cssSelector(".caret")).click();
		// register
		driver.findElement(
				By.cssSelector("a[href='https://demo.opencart.com/index.php?route=account/register']"))
				.click();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

		// register heading

		Assert.assertEquals(driver.findElement(By.cssSelector("#content>h1"))
				.getText(), "Register Account");

		// continue
		WebElement cont = driver
				.findElement(By.cssSelector(".btn.btn-primary"));
		cont.click();

		// verify warning message
		Thread.sleep(5000);
		WebElement warning = driver.findElement(By
				.cssSelector(".alert.alert-danger"));
		boolean b2 = warning.getText().contains(
				"Warning: You must agree to the Privacy Policy!");
		if (b2)
			System.out
					.println("Warning: You must agree to the Privacy Policy!");

		// PART 2 : For 'Your Personal Details'
		// first name 33 characters
		driver.findElement(By.cssSelector("#input-firstname")).sendKeys(
				"Srinivasuabcdefghijklmnopqrtstuvwx");
		driver.findElement(By.cssSelector(".btn.btn-primary")).click();
		Thread.sleep(2000);

		Assert.assertEquals(
				driver.findElement(
						By.xpath("//*[@id='account']/div[2]/div/div"))
						.getText(),
				"First Name must be between 1 and 32 characters!");

		driver.findElement(By.cssSelector("#input-firstname")).clear();
		driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div"))
				.sendKeys("Srinivasu");

		// last name 33 characters
		driver.findElement(By.cssSelector("#input-lastname")).sendKeys(
				"Kalaabcdefghijklmnopqrtstuvwxyzabc");
		driver.findElement(By.cssSelector(".btn.btn-primary")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		Thread.sleep(2000);

		Assert.assertEquals(
				driver.findElement(
						By.xpath("//*[@id='account']/div[3]/div/div"))
						.getText(),
				"Last Name must be between 1 and 32 characters!");

		WebElement ln = driver.findElement(By.cssSelector("#input-lastname"));
		ln.clear();
		ln.sendKeys("Kala");

		driver.findElement(By.cssSelector("#input-email")).sendKeys(
				"srinivasu8.97@gmail.com");
		driver.findElement(By.cssSelector("#input-telephone")).sendKeys(
				"8985053099");

		// PART 3 : For 'Your Address'
		driver.findElement(By.cssSelector("#input-address-1")).sendKeys(
				"Akshay Tech Park");
		driver.findElement(By.cssSelector("#input-city")).sendKeys("Bangalore");
		driver.findElement(By.cssSelector("#input-postcode"))
				.sendKeys("560066");
		// country india
		WebElement country = driver.findElement(By
				.cssSelector("#input-country"));
		Select sel = new Select(country);
		sel.selectByVisibleText("India");

		// state karnataka
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement state = driver.findElement(By.cssSelector("#input-zone"));
		Select sel2 = new Select(state);
		sel2.selectByVisibleText("Karnataka");

		// PART 4 : For 'Password'
		// password
		driver.findElement(By.cssSelector("#input-password")).sendKeys("54395");
		driver.findElement(By.cssSelector("#input-confirm")).sendKeys("54395");

		// PART 4 : For 'Newsletter'
		// newsletter
		driver.findElement(
				By.cssSelector("input[type='radio'][value='1'][name='newsletter']"))
				.click();
		driver.findElement(By.cssSelector("input[type='checkbox']")).click();

		// click to continue
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]"))
				.click();

		Assert.assertEquals(
				driver.findElement(By.xpath("//*[@id='content']/h1")).getText(),
				"Your Account Has Been Created!");

		driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='content']/ul[2]/li[1]/a"))
				.click();
	}

	@After
	public void afterMethod() {
		System.out.println("Execution finished");

	}

	@AfterClass
	public static void afterClass() {
		driver.close();
	}

}
