package pack2;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab6_1_Lab4_JUnit {

	public static WebDriver driver;

	@BeforeClass
	public static void beforeClass() {
		driver = new FirefoxDriver();
		driver.get("http://demo.opencart.com/");
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@Before
	public void beforeMethod() {
		System.out.println("Before Method");
	}

	@Test
	public void main() throws InterruptedException {

		// my account
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/i"))
				.click();
		// login
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[2]/a"))
				.click();
		// email
		driver.findElement(By.xpath("//*[@id='input-email']")).sendKeys(
				"srinivasu958@gmail.com");
		// password
		driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys(
				"543958srinu");
		// submit login
		driver.findElement(
				By.xpath("//*[@id='content']/div/div[2]/div/form/input"))
				.click();
		// components
		driver.findElement(By.xpath("//*[@id='menu']/div[2]/ul/li[3]/a"))
				.click();
		// monitor
		driver.findElement(
				By.xpath("//*[@id='menu']/div[2]/ul/li[3]/div/div/ul/li[2]/a"))
				.click();
		// 15 to 25
		WebElement show = driver
				.findElement(By.xpath("//*[@id='input-limit']"));
		Select sel = new Select(show);
		sel.selectByVisibleText("25");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// add to cart
		driver.findElement(
				By.xpath("//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]"))
				.click();
		Thread.sleep(6000);

		/*
		 * driver.findElement(
		 * By.xpath("//*[@id='content']/div[1]/div[1]/ul[2]/li[2]/a")) .click();
		 */

		// specification
		// driver.findElement(By.xpath("//a[@href='#tab-specification']")).click();
		// driver.findElement(By.linkText("Specification")).click();
		// driver.get("http://demo.opencart.com/index.php?route=product/product&product_id=42");
		driver.findElement(By.xpath("//a[@href='#tab-specification']")).click();
		Assert.assertEquals(
				"Processor",
				driver.findElement(
						By.xpath("//*[@id='tab-specification']/table/thead/tr/td"))
						.getText());
		Assert.assertEquals(
				"Clockspeed",
				driver.findElement(
						By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[1]"))
						.getText());
		Assert.assertEquals(
				"100mhz",
				driver.findElement(
						By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[2]"))
						.getText());
		// add to wish list
		driver.findElement(
				By.xpath("//*[@id='content']/div[1]/div[2]/div[1]/button[1]"))
				.click();
		Thread.sleep(3000);
		// success message of apple cinema 30"
		WebElement success1 = driver.findElement(By
				.xpath("html/body/div[2]/div[1]"));
		boolean b3 = success1.getText().contains(
				"Success: You have added Apple Cinema 30\" to your wish list!");
		if (b3)
			System.out
					.println("Success: You have added Apple Cinema 30\" to your wish list!");
		else
			System.out.println(success1.getText());
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='search']/input")).sendKeys(
				"Mobile");
		// search
		driver.findElement(By.xpath("//*[@id='search']/span/button")).click();
		driver.findElement(By.xpath("//*[@id='description']")).click();
		// htc touch hd link
		driver.findElement(By.xpath("//*[@id='button-search']")).click();
		// submit
		driver.findElement(
				By.xpath("//*[@id='content']/div[4]/div[1]/div/div[2]/h4/a"))
				.click();
		// 1 to 3
		WebElement q = driver
				.findElement(By.xpath("//*[@id='input-quantity']"));
		q.clear();
		q.sendKeys("3");
		// add to cart
		// add to cart
		driver.findElement(By.xpath("//*[@id='button-cart']")).click();
		// add to cart success message

		Thread.sleep(3000);
		WebElement success2 = driver.findElement(By
				.xpath("html/body/div[2]/div[1]"));
		boolean b4 = success2.getText().contains("");
		if (b4)
			System.out
					.println("Success: You have added HTC Touch HD to your shopping cart!");
		else
			System.out.println(success2.getText());
		Thread.sleep(3000);
		// view cart
		driver.findElement(By.xpath("//*[@id='cart']/button")).click();
		// check htc touch hd name
		Thread.sleep(1000);
		Assert.assertEquals(
				"HTC Touch HD",
				driver.findElement(
						By.xpath("//*[@id='cart']/ul/li[1]/table/tbody/tr/td[2]/a"))
						.getText());
		// checkout
		WebElement co = driver.findElement(By
				.xpath("//*[@id='cart']/ul/li[2]/div/p/a[2]/strong"));

		boolean b6 = co.getText().contains("Checkout");

		if (b6)
			System.out.println("Checkout");
		co.click();
		Thread.sleep(2000);
		// my account
		// delay
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a")).click();
		// Logout
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[5]/a"))
				.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// title
		Assert.assertEquals("Account Logout",
				driver.findElement(By.xpath("//*[@id='content']/h1")).getText());
		// continue
		driver.findElement(By.cssSelector(".btn.btn-primary")).click();
	}

	@After
	public void afterMethod() {
		System.out.println("After Method");
	}

	@AfterClass
	public static void afterClass() {
		driver.close();
	}
}
